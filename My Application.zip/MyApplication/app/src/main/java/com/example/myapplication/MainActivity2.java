package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;
import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            String des = "";
            String infoC = "";
            String opening = "";

            des = bundle.getString("des");
            infoC = bundle.getString("info");
            opening = bundle.getString("open");
            String link =  bundle.getString("link");

            TextView t1 = (TextView) findViewById(R.id.listarInfo);
            TextView t2 = (TextView) findViewById(R.id.listarWeb);
            t1.setText(des + "\n" + infoC + "\n" + opening);
            t2.setText(link);
        }
    }

    public void aceptarycerrar(View v){
        /*EditText editText = (EditText) findViewById(R.id.editor);
        String cadena = editText.getText().toString();
        Intent i = new Intent();
        i.putExtra("info",cadena);
        setResult(RESULT_OK, i);
        this.finish();*/
    }
    // discharge imagens de internet

    /*public void mostraInfo(View v){
        Intent i = new Intent(this, MainActivity2.class);
        i.putExtra("dato1","La cantidad de alumno es:");
        i.putExtra("dato2",85);
        startActivityForResult(i, 5);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String leyenda = "codigo de respuesta: " + requestCode + " resultado: " + resultCode;

        if(resultCode == RESULT_OK){
            String info = data.getExtras().getString("info");
            Toast.makeText(this, info, Toast.LENGTH_LONG).show();
        }
        else
            Toast.makeText(this, leyenda, Toast.LENGTH_LONG).show();
    }

    public void mandarInfo(View v){
        Intent i = new Intent();
        i.setAction(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, "Texto que se envia");

        if(i.resolveActivity(getPackageManager()) != null){
            startActivity(i);
        }
    }*/
}