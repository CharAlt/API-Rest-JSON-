package com.example.myapplication;

import android.media.Image;
import android.widget.ImageView;

public class Vendor {
    private String nombre;
    private String abiertoCerrado;
    private int pos;

    public int getPos() {
        return pos;
    }

    public void setPos(int imagen) {
        this.pos = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAbiertoCerrado() {
        return abiertoCerrado;
    }

    public void setAbiertoCerrado(String abiertoCerrado) {
        this.abiertoCerrado = abiertoCerrado;
    }

    @Override
    public String toString() {
        return "nombre: " + getNombre() + " estado: " + getAbiertoCerrado();
    }
}
