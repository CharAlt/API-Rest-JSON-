package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.RequestBuilder;

import java.util.List;

public class Adaptador extends BaseAdapter {

    private static LayoutInflater inflater = null;
    private Context contexto;
    private List<Vendor> vendors;
    private List<RequestBuilder<Drawable>> imagenes;
    public Adaptador(Context c, List<Vendor> v,List<RequestBuilder<Drawable>> imagenes){
        this.contexto  = c;
        vendors = v;

        this.imagenes = imagenes;
        inflater = (LayoutInflater) contexto.getSystemService(contexto.LAYOUT_INFLATER_SERVICE);
    }

    public List<Vendor> getLista(){
        return vendors;
    }
    @Override
    public View getView(int i, View convertView, ViewGroup parent) {

        final  View vista = inflater.inflate(R.layout.elemento_lista, null);

        TextView t1 = (TextView) vista.findViewById(R.id.textoNombre);
        TextView t2 = (TextView) vista.findViewById(R.id.estado);
        ImageView imagen = (ImageView) vista.findViewById(R.id.avatar);


        t1.setText(vendors.get(i).getNombre());
        t2.setText(vendors.get(i).getAbiertoCerrado());
        if(vendors.get(i).getAbiertoCerrado().equals("Abierto ahora mismo"))
            t2.setTextColor(Color.parseColor("#008000"));
        else
            t2.setTextColor(Color.parseColor("#FF0000"));
        imagenes.get(i).into(imagen);

        return vista;
    }

    @Override
    public int getCount() {
        return vendors.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }


}
