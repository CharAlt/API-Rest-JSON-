package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;

import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class MainActivity extends AppCompatActivity {
    private final String urlJson = "https://gist.githubusercontent.com/F-3r/e7c9c0f5fb3e23b45573c6123499e563/raw/50d7dd2170ad1bd79b964d94567f17187449ea4c/vendorlust.json";
    private RequestQueue requestQueue;
    private List<Vendor> vendors;
    private Detallado detallado;
    private Calendar now = Calendar.getInstance();
    ;
    int horaActual, minutosActual;
    List<RequestBuilder<Drawable>> imagenes;
    ListView vistas;
    EditText edit;
    int posicionLlamada;
    private int cant = 50;
    private Adaptador adap;
    private List<Vendor> vendedores;
    private boolean acceder = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vendors = new ArrayList<>();
        vistas = (ListView) findViewById(R.id.listaDeVista);
        imagenes = new ArrayList<>();
        edit = (EditText) findViewById(R.id.buscador);
        requestQueue = Volley.newRequestQueue(this);
        ObtenerJson();

        vistas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                posicionLlamada = position;
                listarDetallado();
            }
        });

        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s != "") {
                    Adaptador aux;
                    List<RequestBuilder<Drawable>> imamgenAux = new ArrayList<>();
                    vendedores = adap.getLista().stream().filter(elem -> elem.getNombre().startsWith(String.valueOf(s))).collect(Collectors.toList());

                    for(int i=0; i<vendedores.size();i++)
                        imamgenAux.add(imagenes.get(vendedores.get(i).getPos()));

                    aux = new Adaptador(MainActivity.this, vendedores, imamgenAux);
                    vistas.setAdapter(aux);
                    acceder = true;
                } else {
                    vistas.setAdapter(adap);
                    acceder = false;
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    /* incovenientes:
    // necesite crear un modulo de obtener json varias veces, ya que las referencias al salir no se me mantienen, quizas usando otra metodologia si pero de momento con Volley no,
    // no pude solucionar el problema, a la lista vendors le agrego los datos perfecto y dentro de onrespone funciona perfecto
    // pero al salir no mantiene la referencia, lo que ocasiana que deba llamar al modulo por cada necesidad de datos, 3 llamadas en total
    // obvio que es ineficiente ya que de una sola llamada deberia almacenar toda la informacion posible, relentizando asi la app.
    // espero puedan contemplar eso :p, posteriormente lo solucionare
    // esto relentiza al carga la actividad con mas info(MainActivity 2)
    */


    /*
     * obtiene los datos nuevamente para ir a MainActivity2
     * */
    private void listarDetallado() {
        JsonArrayRequest requerimiento = new JsonArrayRequest(Request.Method.GET
                , urlJson, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        JSONObject infoContacto;
                        JSONObject openingHours;
                        detallado = new Detallado();
                        JSONObject obj;
                        String link = "";
                        try {
                            if(acceder)
                                obj = response.getJSONObject(vendedores.get(posicionLlamada).getPos());
                            else
                                obj = response.getJSONObject(posicionLlamada);

                            try {
                                detallado.setDescripcion(obj.getString("description"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            try {
                                infoContacto = obj.getJSONObject("contact_info");
                                detallado.setInfoContacto(
                                        "numero de telefono: " + infoContacto.getString("phone_number") +
                                                "\ndireccion de mail: " + infoContacto.getString("email_address") +
                                                "\nwebsite: " + infoContacto.getString("website_url")
                                );
                                link = infoContacto.getString("website_url");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            // podria hacerse mas eficiente si opening_hours fuera un vector

                            try {
                                openingHours = obj.getJSONObject("opening_hours");
                                JSONArray dia;
                                String horaApertura = "";
                                String horaCierre = "";
                                try {
                                    dia = openingHours.getJSONArray(quediaes());
                                    try {
                                        horaApertura = dia.getJSONObject(0).getString("opens_at");
                                        horaCierre = dia.getJSONObject(0).getString("closes_at");
                                    } catch (JSONException e) {
                                    }
                                    detallado.setOpeningHours("apertura: " + horaApertura + "\n" + "cierre: " + horaCierre);
                                } catch (JSONException e) {
                                }
                            } catch (JSONException e) {
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        Intent i = new Intent(MainActivity.this, MainActivity2.class);
                        i.putExtra("des", detallado.getDescripcion());
                        i.putExtra("info", detallado.getInfoContacto());
                        i.putExtra("open", detallado.getOpeningHours());
                        i.putExtra("link", link);
                        startActivity(i);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "fallo", Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(requerimiento);
    }

    /*
     * Obtiene el json para listar en listview en MainActivity
     * los datos son nombre de vendedor, imagen y opening hours del dia actual
     * */
    private void ObtenerJson() {

        JsonArrayRequest requerimiento = new JsonArrayRequest(Request.Method.GET
                , urlJson, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Vendor ven;
                        JSONObject obj;
                        JSONArray objDia;
                        String abiertoCerrado = "";
                        String apertura, cierre;
                        String horasApe, minutosApe;
                        String horaCierre, minutosCierre;
                        horaActual = now.get(Calendar.HOUR_OF_DAY);
                        minutosActual = now.get(Calendar.MINUTE);
                        List<String> urls = new ArrayList<>();

                        // cargo solamente algunos elementos para que no sea tan pesado
                        for (int i = 0; i < cant; i++) {
                            ven = new Vendor();
                            ven.setPos(i);
                            abiertoCerrado = "S/N";
                            try {
                                obj = response.getJSONObject(i);
                                ven.setNombre(obj.getString("display_name"));
                                urls.add(obj.getJSONObject("hero_image").getString("url"));

                                // chequear el dia y hora para ver si esta abierto
                                try {
                                    objDia = obj.getJSONObject("opening_hours").getJSONArray(quediaes());
                                    apertura = objDia.getJSONObject(0).getString("opens_at");
                                    cierre = objDia.getJSONObject(0).getString("closes_at");
                                    horasApe = apertura.substring(0, 2);
                                    minutosApe = apertura.substring(3, 5);
                                    horaCierre = cierre.substring(0, 2);
                                    minutosCierre = cierre.substring(3, 5);

                                    if (Integer.parseInt(horasApe) == 0)
                                        horasApe = "24";

                                    if (Integer.parseInt(horaCierre) == 0)
                                        horaCierre = "24";

                                    if (horaActual > Integer.parseInt(horasApe)) {
                                        if (horaActual < Integer.parseInt(horaCierre))
                                            abiertoCerrado = "Abierto ahora mismo";
                                        else {
                                            if (horaActual == Integer.parseInt(horaCierre)) {
                                                if (minutosActual < Integer.parseInt(minutosCierre))
                                                    abiertoCerrado = "Abierto ahora mismo";
                                                else
                                                    abiertoCerrado = "carrado";
                                            } else
                                                abiertoCerrado = "carrado";
                                        }
                                    } else {
                                        if (horaActual == Integer.parseInt(horasApe)) {
                                            if (minutosActual >= Integer.parseInt(minutosApe)) {
                                                abiertoCerrado = "Abierto ahora mismo";
                                            } else
                                                abiertoCerrado = "carrado";
                                        } else
                                            abiertoCerrado = "carrado";
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                ven.setAbiertoCerrado(abiertoCerrado);
                                vendors.add(ven);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        descargarImagenes(urls);
                        adap = new Adaptador(MainActivity.this, vendors, imagenes);
                        vistas.setAdapter(adap);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "fallo", Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(requerimiento);
    }


    // retorna el dia actual
    public String quediaes() {
        String dia = "";

        int dia2 = now.get(Calendar.DAY_OF_WEEK);
        switch (dia2) {
            case 1:
                dia = "sunday";
                break;
            case 2:
                dia = "monday";
                break;
            case 3:
                dia = "tuesday";
                break;
            case 4:
                dia = "wednesday";
                break;
            case 5:
                dia = "thursday";
                break;
            case 6:
                dia = "friday";
                break;
            case 7:
                dia = "saturday";
                break;
        }

        return dia;
    }

    /*
     * usamos la libreria Glide para descargar las imagenes
     * */
    public void descargarImagenes(List<String> urls) {
        RequestBuilder<Drawable> bit;
        for (int i = 0; i < urls.size(); i++) {
            bit = Glide.with(MainActivity.this).load(urls.get(i));
            imagenes.add(bit);
        }

    }
}


    /*
    * vuelve a recuperar la info para buscar el vendedor por nombre de vendedor
    * lo mejor seria al principio almacenanarlo en una estructura vector y ordenarlo y seguirla usando
    * o una estructura ordenada en si misma como la familia de arboles B
    * */
